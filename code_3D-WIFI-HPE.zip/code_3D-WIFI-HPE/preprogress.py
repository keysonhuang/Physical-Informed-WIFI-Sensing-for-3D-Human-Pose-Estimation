import pywt
import numpy as np
import torch
import scipy.io as scio
import matplotlib.pyplot as plt
from torch.utils.data import Dataset


class SignalProcessor:
    @staticmethod
    def apply_wavelet_transform_1d(data, wavelet='haar'):
        data = torch.from_numpy(data)
        data = data.unsqueeze(0)
        data = data.numpy()

        coeffs = []
        for i in range(data.shape[0]):
            coeff1d = []
            for j in range(data.shape[1]):
                row_coeffs = []
                for k in range(data.shape[2]):
                    cA, _ = pywt.dwt(data[i, j, k], wavelet=wavelet, mode='periodization')
                    row_coeffs.append(cA)
                coeff1d.append(row_coeffs)
            coeffs.append(coeff1d)
        coeffs = np.array(coeffs)
        coeffs = coeffs.squeeze(0)
        return coeffs

    @staticmethod
    def unwrap_phase(phase_data):
        unwrapped_phase_data = np.zeros_like(phase_data)
        for antenna in range(phase_data.shape[0]):
            for subcarrier in range(phase_data.shape[1]):
                unwrapped_phase_data[antenna, subcarrier, :] = np.unwrap(phase_data[antenna, subcarrier, :])
        unwrapped_phase_data = torch.from_numpy(unwrapped_phase_data)
        unwrapped_phase_data = unwrapped_phase_data.numpy()
        return unwrapped_phase_data

    @staticmethod
    def sanitize_phase(data_phase):
        M, N, T = data_phase.shape
        fi = 312.5 * 2
        calibrated_phase = np.zeros_like(data_phase)
        for t in range(T):
            ai = 2 * np.pi * fi * np.tile(np.arange(N), M)
            bi = np.ones(M * N)
            ci = data_phase[:, :, t].flatten()
            A = np.dot(ai, ai)
            B = np.dot(ai, bi)
            C = np.dot(bi, bi)
            D = np.dot(ai, ci)
            E = np.dot(bi, ci)
            denominator = A * C - B ** 2
            rho_opt = (B * E - C * D) / denominator
            beta_opt = (B * D - A * E) / denominator
            for m in range(M):
                subcarrier_idx = np.arange(N)
                phase_adjustment = 2 * np.pi * fi * subcarrier_idx * rho_opt + beta_opt
                calibrated_phase[m, :, t] = data_phase[m, :, t] + phase_adjustment
        return calibrated_phase

    @staticmethod
    def preprocess_csi_frame(frame_path):
        data_amp = scio.loadmat(frame_path)['CSIamp']
        data_phase = scio.loadmat(frame_path)['CSIphase']

        data_amp[np.isinf(data_amp)] = np.nan
        for i in range(data_amp.shape[-1]):
            temp_col = data_amp[:, :, i]
            nan_num = np.count_nonzero(temp_col != temp_col)
            if nan_num != 0:
                temp_not_nan_col = temp_col[temp_col == temp_col]
                temp_col[np.isnan(temp_col)] = temp_not_nan_col.mean()

        data_phase[np.isinf(data_phase)] = np.nan
        for i in range(data_phase.shape[-1]):
            temp_col = data_phase[:, :, i]
            nan_num = np.count_nonzero(temp_col != temp_col)
            if nan_num != 0:
                temp_not_nan_col = temp_col[temp_col == temp_col]
                temp_col[np.isnan(temp_col)] = temp_not_nan_col.mean()

        complex_data = data_amp * (np.cos(data_phase) + 1j * np.sin(data_phase))
        fft_csi = np.fft.fft(complex_data, axis=1)
        fft_csi[:, 0, :] = 0
        sampling_rate = 1000
        num_subcarriers = fft_csi.shape[1]
        frequencies = np.fft.fftfreq(num_subcarriers, d=1.0 / sampling_rate)
        mask = (np.abs(frequencies) > 0) & (np.abs(frequencies) <= 100)
        mask = mask.reshape(1, -1, 1)
        fft_csi = fft_csi * mask
        filtered_csi_data = np.fft.ifft(fft_csi, axis=1)

        data_amp = np.abs(filtered_csi_data)
        data_phase = np.angle(filtered_csi_data)

        data_amp = SignalProcessor.apply_wavelet_transform_1d(data_amp)
        data_amp = (data_amp - np.min(data_amp)) / (np.max(data_amp) - np.min(data_amp))

        data_phase = SignalProcessor.unwrap_phase(data_phase)
        data_phase = SignalProcessor.sanitize_phase(data_phase)
        data_phase = (data_phase - np.min(data_phase)) / (np.max(data_phase) - np.min(data_phase))

        return np.concatenate([data_amp, data_phase], axis=-1)