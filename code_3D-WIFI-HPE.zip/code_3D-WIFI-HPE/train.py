import yaml
import torch
import torch.nn as nn
from model import PhysicsGuidedPoseEstimator
from mmfi import make_dataset, make_dataloader
import os
from evaluation import calculate_mpjpe, calculate_pa_mpjpe, calculate_pck

if __name__ == '__main__':
    dataset_root = 'MMFi_Dataset\Dataset'
    config_file = 'config.yaml'
    with open(config_file, 'r') as fd:
        config = yaml.load(fd, Loader=yaml.FullLoader)

    train_dataset, val_dataset = make_dataset(dataset_root, config)

    rng_generator = torch.manual_seed(config['init_rand_seed'])
    train_loader = make_dataloader(train_dataset, is_training=True, generator=rng_generator, **config['train_loader'])
    val_loader = make_dataloader(val_dataset, is_training=False, generator=rng_generator, **config['validation_loader'])

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    model = PhysicsGuidedPoseEstimator().to(device)

    criterion_L2 = nn.MSELoss().to(device)
    env_criterion = nn.CrossEntropyLoss().to(device)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.001, momentum=0.9)

    num_epochs = 100
    n_epochs = 10
    n_epochs_decay = 90
    epoch_count = 1
    def lambda_rule(epoch):
        lr_l = 1.0 - max(0, epoch + epoch_count - n_epochs) / float(n_epochs_decay + 1)
        return lr_l

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='min',
        factor=0.5,
        patience=5,
        verbose=True,
        min_lr=1e-6
    )


    model_save_dir = 'saved_models'
    os.makedirs(model_save_dir, exist_ok=True)
    recent_models = []
    best_mpjpe = float('inf')
    best_model_path = os.path.join(model_save_dir, 'best_model.pth')
    # TODO: Codes for training (and saving models)
    # Just an example for illustration.
    for i in range(num_epochs):
        model.train()
        for batch_idx, data in enumerate(train_loader):

            csi_data = data['input_wifi-csi'] .to(device)
            action = data['action']
            action_tensor = torch.tensor([int(s[1:]) - 1 for s in action], dtype=torch.long).to(device)
            pose_labels = data['output_3D'].to(device)
            scenes = data['scene']
            env_labels = torch.tensor([int(scene[1:]) for scene in scenes]).to(device) - 1
            # labels = data['input_rgb'] .to(device)
            optimizer.zero_grad()
            pose_out, domain_out = model(csi_data, action_tensor)
            loss_pose = criterion_L2(pose_out, pose_labels)
            loss_env = env_criterion(domain_out, env_labels)
            mpjpe = calculate_mpjpe(pose_out, pose_labels)
            total_loss = loss_pose + 0.05 * loss_env
            total_loss.backward()
            optimizer.step()

            _, predicted = torch.max(domain_out.data, 1)
            env_correct = (predicted == env_labels).sum().item()
            env_num = env_labels.size(0)
            batch_acc = env_correct / env_num

            print("idx：{}，total_Loss={}，mpjpe={},acc={}".
                  format(batch_idx, total_loss.item(), mpjpe,batch_acc))
        print(f"Epoch {i + 1} completed")
        current_lr = scheduler.get_last_lr()[0]
        print(f"Epoch {i + 1} completed. Current learning rate: {current_lr}")


    # TODO: Codes for test (if)
        model.eval()
        total_mpjpe = 0.0
        total_pa_mpjpe = 0.0
        total_pck50 = 0.0
        total_pck40 = 0.0
        total_pck30 = 0.0
        total_pck20 = 0.0
        num_samples = 0
        with torch.no_grad():
            for batch_idx, data in enumerate(val_loader):
                val_csi_data = data['input_wifi-csi'].to(device)
                val_action = data['action']
                val_action_label = torch.tensor([int(s[1:]) - 1 for s in val_action], dtype=torch.long).to(device)

                val_labels = data['output_3D'].to(device)
                val_scenes = data['scene']
                val_env_labels = torch.tensor([int(scene[1:]) for scene in val_scenes]).to(device) - 1
                # labels = data['input_rgb'] .to(device)

                optimizer.zero_grad()

                outputs, domain_out = model(val_csi_data, val_action_label)

                mpjpe = calculate_mpjpe(outputs, val_labels)
                pa_mpjpe = calculate_pa_mpjpe(outputs, val_labels)
                pck50 = calculate_pck(outputs, val_labels, 50)
                pck40 = calculate_pck(outputs, val_labels, 40)
                pck30 = calculate_pck(outputs, val_labels, 30)
                pck20 = calculate_pck(outputs, val_labels, 20)

                total_mpjpe += mpjpe.item() * val_csi_data.size(0)  # 假设calculate_mpjpe返回的是标量
                total_pa_mpjpe += pa_mpjpe * val_csi_data.size(0)
                total_pck50 += pck50 * val_csi_data.size(0)
                total_pck40 += pck40 * val_csi_data.size(0)
                total_pck30 += pck30 * val_csi_data.size(0)
                total_pck20 += pck20 * val_csi_data.size(0)

                num_samples += val_csi_data.size(0)
                # print("Batch VAL MPJPE={}".format(mpjpe))
        current_mpjpe = total_mpjpe / num_samples
        current_pa_mpjpe = total_pa_mpjpe / num_samples
        current_pck50 = total_pck50 / num_samples
        current_pck40 = total_pck40 / num_samples
        current_pck30 = total_pck30 / num_samples
        current_pck20 = total_pck20 / num_samples
        print("VAL MPJPE={}, VAL PAMPJPE={}, PCK@50={}, PCK@40={}, PCK@30={},, PCK@20={}"
              .format(current_mpjpe, current_pa_mpjpe, current_pck50, current_pck40, current_pck30, current_pck20))

        if current_mpjpe < best_mpjpe:
            best_mpjpe = current_mpjpe
            torch.save({
                'epoch': i + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'scheduler_state_dict': scheduler.state_dict(),
                'best_mpjpe': best_mpjpe
            }, best_model_path)
            print(f"New best model saved with MPJPE: {best_mpjpe:.2f}mm")

        recent_model_path = os.path.join(model_save_dir, f'recent_model_epoch_{i + 1}.pth')
        torch.save({
            'epoch': i + 1,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict()
        }, recent_model_path)

        recent_models.append(recent_model_path)
        if len(recent_models) > 10:
            removed_model = recent_models.pop(0)
            if os.path.exists(removed_model):
                os.remove(removed_model)
                print(f"Removed old model: {removed_model}")
        scheduler.step(current_mpjpe)
    print(f"Best validation MPJPE: {best_mpjpe:.2f}mm")








