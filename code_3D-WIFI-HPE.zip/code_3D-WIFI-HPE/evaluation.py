import numpy as np
import torch
from scipy.spatial.transform import Rotation

def calculate_mpjpe(preds, gt):
    preds = preds.detach().cpu().numpy()
    gt = gt.detach().cpu().numpy()
    joint_distances = np.linalg.norm(preds - gt, axis=2)
    sample_errors = np.mean(joint_distances, axis=1)
    mpjpe = np.mean(sample_errors)
    return mpjpe


def calculate_pa_mpjpe(preds, gt):


    if isinstance(preds, torch.Tensor):
        preds = preds.detach().cpu().numpy()
    if isinstance(gt, torch.Tensor):
        gt = gt.detach().cpu().numpy()

    batch_size = preds.shape[0]
    errors = []
    for i in range(batch_size):
        pred = preds[i]  # (17, 3)
        target = gt[i]  # (17, 3)
        pred_centered = pred - np.mean(pred, axis=0)
        target_centered = target - np.mean(target, axis=0)
        H = pred_centered.T @ target_centered  # (3,3)
        U, _, Vt = np.linalg.svd(H)
        R = Vt.T @ U.T
        if np.linalg.det(R) < 0:
            Vt[-1, :] *= -1
            R = Vt.T @ U.T
        aligned_pred = pred_centered @ R.T

        error = np.linalg.norm(aligned_pred - target_centered, axis=1)  # (17,)
        errors.append(np.mean(error))
    return np.mean(errors)

def calculate_pck(preds, gt, alpha, rs_idx=5, lh_idx=12):
    if isinstance(preds, torch.Tensor):
        preds = preds.detach().cpu().numpy()
    if isinstance(gt, torch.Tensor):
        gt = gt.detach().cpu().numpy()
    batch_size, num_joints = preds.shape[:2]
    total_correct = 0
    total_points = batch_size * num_joints

    for i in range(batch_size):

        rs = gt[i, rs_idx]  #
        lh = gt[i, lh_idx]  #
        torso_size = np.linalg.norm(rs - lh)

        if torso_size < 1e-6:
            total_points -= num_joints
            continue

        for j in range(num_joints):
            pred = preds[i, j]
            target = gt[i, j]
            dist = np.linalg.norm(pred - target)
            normalized_dist = dist / torso_size

            if normalized_dist <= (alpha / 100.0):
                total_correct += 1

    if total_points == 0:
        return 0.0

    return total_correct / total_points


