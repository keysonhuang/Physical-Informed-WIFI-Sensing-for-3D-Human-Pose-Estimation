import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Function


class GradientReversalFunction(Function):
    @staticmethod
    def forward(ctx, x, lambda_):
        ctx.lambda_ = lambda_
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.lambda_, None


def grad_reverse(x, lambda_=1.0):
    return GradientReversalFunction.apply(x, lambda_)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion * planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out


class CoarseFeatureExtractor(nn.Module):
    def __init__(self, block, num_blocks):
        super(CoarseFeatureExtractor, self).__init__()
        self.in_planes = 64
        self.conv1 = nn.Conv2d(342, 64, kernel_size=(3, 1), stride=(1, 1), padding=(1, 0), bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=(3, 1), stride=(2, 1), padding=(1, 0))
        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=(2, 1))
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=(2, 1))
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=(2, 1))
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))

    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for s in strides:
            layers.append(block(self.in_planes, planes, s))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.maxpool(out)
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = self.avgpool(out)
        out = torch.flatten(out, 1)
        return out


class PhysicsGuidedPoseEstimator(nn.Module):
    def __init__(self, num_actions=27, input_dim=342, d_model=128, nhead=8,
                 num_encoder_layers=1, num_joints=17, dropout=0.1):
        super().__init__()

        self.lambda_grl = 1.0
        self.num_actions = num_actions

        self.pgma_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=342, nhead=6, dim_feedforward=1024, dropout=0.1, activation='relu'),
            num_layers=2
        )

        self.coarse_feature_extractor = CoarseFeatureExtractor(BasicBlock, [2, 2, 2, 2])

        self.action_semantic_embedding = nn.Embedding(num_embeddings=self.num_actions, embedding_dim=512)

        self.hierarchical_fusion_decoder = nn.Sequential(
            nn.Linear(512 + 512, 1024),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(1024, 17 * 3)
        )

        self.physics_disentangled_adaptor = nn.Sequential(
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 4)
        )

    def forward(self, x, action_label):
        batch = x.size(0)

        x = x.permute(0, 3, 1, 2)
        x = x.reshape(batch, 15, -1)

        x = x.permute(1, 0, 2)
        x = self.pgma_encoder(x)
        x = x.permute(1, 2, 0)

        x = x.unsqueeze(-1)
        features = self.coarse_feature_extractor(x)

        action_features = self.action_semantic_embedding(action_label)

        combined_features = torch.cat([features, action_features], dim=1)

        pose_out = self.hierarchical_fusion_decoder(combined_features)
        pose_out = pose_out.view(batch, 17, 3)

        domain_out = self.physics_disentangled_adaptor(grad_reverse(features, self.lambda_grl))

        return pose_out, domain_out